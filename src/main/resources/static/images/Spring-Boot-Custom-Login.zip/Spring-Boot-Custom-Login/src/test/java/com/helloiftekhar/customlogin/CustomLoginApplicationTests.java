package com.helloiftekhar.customlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomLoginApplicationTests {

    @Test
    void contextLoads() {
    }

}
