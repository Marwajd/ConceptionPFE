package com.helloiftekhar.customlogin.Model;

public class ReferenceData {
}
