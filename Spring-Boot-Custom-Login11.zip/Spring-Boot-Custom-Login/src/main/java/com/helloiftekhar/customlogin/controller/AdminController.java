package com.helloiftekhar.customlogin.controller;

import com.helloiftekhar.customlogin.Model.Admin;
import com.helloiftekhar.customlogin.Services.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {
    private AdminService adminService;


    @GetMapping("/home")
    public String home() {
        return "home";
    }


    @GetMapping("/login")
    public String login(Admin admin) {
        return "login";
    }

    @GetMapping("/signup")
    public String signup() {
        return "signup";
    }

    @GetMapping("/")
    public String dashboard() {
        return "dashboard";
    }

}